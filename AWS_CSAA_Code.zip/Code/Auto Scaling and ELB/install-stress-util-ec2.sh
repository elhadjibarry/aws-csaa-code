# Enable the EPEL repo:
sudo amazon-linux-extras install epel -y
# Install the stress utility
sudo yum install stress -y